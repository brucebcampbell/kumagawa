# kumagawa

[![DOI](https://zenodo.org/badge/178958342.svg)](https://zenodo.org/badge/latestdoi/178958342)

[![Build Status](https://travis-ci.org/brucebcampbell/kumagawa.svg?branch=master)](https://travis-ci.org/brucebcampbell/kumagawa)

[![codecov](https://codecov.io/gh/brucebcampbell/kumagawa/branch/master/graph/badge.svg)](https://codecov.io/gh/brucebcampbell/kumagawa)

The goal of kumagawa is to ...

## Installation

You can install the released version of kumagawa from [CRAN](https://CRAN.R-project.org) with:

``` r
install.packages("kumagawa")
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
## basic example code
```

