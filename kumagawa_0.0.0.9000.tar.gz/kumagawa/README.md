# kumagawa

[![DOI](https://zenodo.org/badge/178958342.svg)](https://zenodo.org/badge/latestdoi/178958342)

[![Build Status](https://travis-ci.com/brucebcampbell/kumagawa.svg?branch=master)](https://travis-ci.com/brucebcampbell/kumagawa.svg?branch=master)

[![codecov](https://codecov.io/gh/brucebcampbell/kumagawa/branch/master/graph/badge.svg)](https://codecov.io/gh/brucebcampbell/kumagawa)

[![Downloads](https://img.shields.io/github/downloads/brucebcampbell/kumagawa/total.svg)](https://img.shields.io/github/downloads/brucebcampbell/kumagawa/total.svg)



The goal of kumagawa is to ...

## Installation

You can install the released version of kumagawa from [CRAN](https://CRAN.R-project.org) with:

``` r
install.packages("kumagawa")
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
## basic example code
```

