#' Demo function to return the value of pi
#' @return something like 3.14
#' @export
untested <- function()
    pi
