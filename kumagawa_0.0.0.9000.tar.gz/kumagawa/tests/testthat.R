library(testthat)
library(kumagawa)
#library(codecov.R)
test_check("kumagawa")

#test package
#test_check('codecov.R')
